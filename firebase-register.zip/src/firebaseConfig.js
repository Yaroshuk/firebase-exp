export default {
  apiKey: "AIzaSyC7oq97Y7PqsSPvgt1uaXkfgR6yw4zo_TE",
  authDomain: "register-3637d.firebaseapp.com",
  databaseURL: "https://register-3637d.firebaseio.com",
  projectId: "register-3637d",
  storageBucket: "register-3637d.appspot.com",
  messagingSenderId: "114471273880"
}